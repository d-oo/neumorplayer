# Handoff: Neumorphism Music Player — 랜딩 페이지

## Overview
YouTube 데이터를 재생원으로 쓰는 뉴모피즘 음악 플레이어의 단일 랜딩 페이지입니다.
헤더 → 히어로 타이포("Neumorphism Music Player") → 동작하는 제품 영역(CD 플레이어 + 동영상 자리 + 탐색)
→ 기능 소개 3카드 → 푸터 순의 1열 구성이며, 제품 영역은 실제로 조작 가능한 프로토타입입니다.

## About the Design Files
이 번들의 HTML 파일은 **디자인 레퍼런스**입니다. 의도한 외관과 동작을 보여주는 프로토타입이며,
그대로 배포할 프로덕션 코드가 아닙니다. 작업 목표는 이 HTML 디자인을 대상 코드베이스의 기존 환경
(React, Vue, SwiftUI, 네이티브 등)과 그 관례·라이브러리로 **다시 구현**하는 것입니다.
아직 환경이 없다면 프로젝트에 가장 적합한 프레임워크를 골라 구현하면 됩니다.

파일은 Design Component 형식(`.dc.html`)입니다. 마크업은 `<x-dc>` 안의 인라인 스타일 HTML,
로직은 파일 하단 `<script type="text/x-dc">`의 `class Component`(React 클래스 컴포넌트와 동일한
생명주기 + `renderVals()`가 템플릿 `{{ }}` 값을 공급)입니다. `{{ x }}`는 `renderVals()`의 키,
`<sc-if>`/`<sc-for>`는 조건/반복입니다. 이 구조는 그대로 옮기지 말고 대상 프레임워크의
조건·반복·상태 문법으로 치환하세요.

## Fidelity
**High-fidelity.** 색·타이포·간격·그림자·인터랙션이 모두 확정값입니다. 픽셀 단위로 재현하되,
그림자 스택은 뉴모피즘의 핵심이므로 값(offset/blur/색)을 임의로 단순화하지 마세요.

## Screens / Views

### 랜딩 페이지 (단일 스크린)
- **Purpose**: 제품의 촉각적인 조작감을 직접 만져보게 하고, 검색 → 재생을 체험시킨 뒤 가입으로 보냄.
- **Canvas**: 고정 폭 1280px, 좌우 패딩 22px(`box-sizing: border-box`) → 콘텐츠 폭 1236px.
  루트는 `display: flex; flex-direction: column; gap: 78px`. 배경 `oklch(0.925 0.014 315)`.
- **콘텐츠 정렬**: 헤더 / 제품 영역 / 기능 3카드는 모두 **886px 폭, 가로 가운데**(`align-self: center`).
  히어로와 푸터만 1236px 전체 폭을 씁니다.

#### 1. 헤더 (886 × auto)
- 컨테이너: `padding: 12px 14px 12px 22px`, `border-radius: 22px`, 배경 `oklch(0.935 0.013 315)`,
  그림자 `12px 12px 26px rgba(142,128,166,0.45), -6px -6px 14px rgba(255,255,255,0.7)`,
  테두리 `1px solid rgba(255,255,255,0.8)`. 좌우 `space-between`.
- 좌: 34px 원형 디스크 마크(그라디언트 스택, 중앙 5px 홀) + 워드마크 `NEUMORPLAYER`
  (Space Grotesk 700, 16px, letter-spacing -0.01em, `#6d1a9f`,
  text-shadow `1px 1px 1.5px rgba(120,96,150,0.5), -1px -1px 1.5px rgba(255,255,255,0.95)`).
- 우: **시작하기** 버튼 — `padding: 11px 22px`, radius 13px, 13px/700, `#6d1a9f`,
  배경 `linear-gradient(155deg, oklch(0.94 0.038 312), oklch(0.885 0.055 312))`,
  그림자 `6px 6px 14px rgba(138,110,172,0.5), -4px -4px 11px rgba(255,255,255,0.95), inset 0 1px 0 rgba(255,255,255,0.65)`,
  active 시 `inset 4px 4px 10px rgba(150,120,182,0.5), inset -3px -3px 8px rgba(255,255,255,0.9)`.

#### 2. 히어로 (가운데 정렬, 상단 패딩 26px, 요소 간 gap 26px)
- 배지: pill(`padding: 8px 16px 8px 10px`, radius 99px, 함몰 그림자
  `inset 3px 3px 7px rgba(150,136,175,0.38), inset -3px -3px 6px rgba(255,255,255,0.88)`).
  안에 20×14 보라 사각형(radius 4px, `#6d1a9f`) + 흰 재생 삼각형, 그리고 모노 캡션
  **POWERED BY YOUTUBE**(IBM Plex Mono 11px, letter-spacing 0.16em, `oklch(0.46 0.025 315)`).
- 타이틀 2행: Space Grotesk 700, **92px**, line-height 0.96, letter-spacing -0.045em.
  1행 `Neumorphism` = `oklch(0.34 0.03 315)`, 2행 `Music Player` = `#6d1a9f`.
  두 행 모두 text-shadow `2px 2px 3px rgba(255,255,255,0.95), -2px -2px 4px rgba(128,108,158,0.45~0.5)` (각인 효과).
- 본문: max-width 560px, 16px/1.8, `oklch(0.45 0.025 315)`, `text-wrap: pretty; word-break: keep-all`.
  카피: "눌리고 솟아오르는 물리적인 인터페이스로 음악을 다룹니다. 아티스트와 제목으로 찾아, 고른 곡을 그 자리에서 재생합니다."

#### 3. 제품 영역 (886px, `flex-direction: column; gap: 18px; align-items: center`)
CSS 변수 `--tick-on: #6d1a9f`, `--tick-off: rgba(126,110,156,0.3)`를 이 래퍼에 선언합니다.

**3-1. 상단 행** — `display: flex; align-items: stretch; justify-content: center; gap: 18px`

(a) **CD 플레이어 카드 340 × 297** (`flex: none`, `padding: 18px`, radius 24px,
배경 `oklch(0.935 0.013 315)`, 그림자 `15px 15px 30px rgba(142,128,166,0.5), -7px -7px 15px rgba(255,255,255,0.65)`,
내부 `flex-direction: column; gap: 15px`)
- 상단 행(gap 14px): 좌 **디스크 166×166**, 우 **볼륨 노브 컬럼**(`flex: 1`, 가운데 정렬).
- 디스크: 원형, 배경은 4겹 스택 —
  `radial-gradient(circle at 50% 50%, oklch(0.935 0.013 315) 0 28px, transparent 28px 30px)`(중앙 홀),
  `repeating-radial-gradient(circle at 50% 50%, rgba(126,110,156,0.13) 0 1px, rgba(255,255,255,0) 1px 3px)`(트랙 골),
  `conic-gradient(from 210deg, …)`(광택), `linear-gradient(150deg, rgba(179,68,255,0.14), transparent 70%)`,
  바탕 `oklch(0.905 0.014 315)`. 그림자 `7px 7px 16px rgba(146,132,170,0.5), -6px -6px 14px rgba(255,255,255,0.95)`.
  내부에 102px 함몰 링, 60px 허브. `cursor: grab` → 드래그 중 `grabbing`.
  **회전은 transform으로만** 갱신(리렌더 없음).
- 디스크 중앙: 56px 솟은 원 안에 38px **재생/일시정지** 버튼(`#6d1a9f`, hover `oklch(0.32 0.14 305)`,
  active 함몰). 재생 중이면 2줄 pause 아이콘, 정지면 삼각형.
- 노브: 92×92 히트영역. **25개 눈금**을 `transform: rotate(-135deg + 11.25deg*i) translateY(-(34 + len/2))`로 배치,
  길이 `i % 6 === 0 ? 11 : 8`px, 폭 3px. 점등 눈금은 `--tick-on` + `box-shadow: 0 0 9px`, 소등은 `--tick-off`.
  중앙 60px 솟은 원 + 50px 다이얼(`conic-gradient` 금속 질감, 12시 방향 3×10px 보라 인디케이터).
  각도 범위 **-135° ~ +135°**(270° = 볼륨 0~1). 아래에 모노 12px 볼륨 라벨(`38%` 형식, margin-top -10px).
- 곡 정보 행: 좌측에 제목(20px/800, letter-spacing -0.035em)과 아티스트 · 앨범(12.5px, `oklch(0.47 0.025 315)`, 말줄임),
  우측에 **반복 버튼** 38px 원형. 꺼짐 = 솟음 + `oklch(0.56 0.02 315)`, 켜짐 = 함몰 + `#6d1a9f`.
- 진행 행: 좌 경과(모노 11px, 34px 폭) / 트랙(높이 9px, radius 99px, 함몰
  `inset 3px 3px 6px rgba(150,136,175,0.6), inset -2px -2px 5px rgba(255,255,255,0.95)`, 내부 4px `#6d1a9f` 진행바) /
  우 남은 시간(`-1:24` 형식).

(b) **동영상 자리 528 × 297** — radius 20px, 함몰
`inset 5px 5px 12px rgba(150,136,175,0.42), inset -4px -4px 9px rgba(255,255,255,0.9)`,
배경 `repeating-linear-gradient(135deg, rgba(118,100,145,0.1) 0 8px, rgba(118,100,145,0.03) 8px 16px)` +
`oklch(0.915 0.014 315)`. 가운데 58px 솟은 원 + 재생 삼각형, 모노 라벨 `VIDEO 528 × 297`,
설명 "동영상 자리 (플레이스홀더)". **구현 시 여기에 YouTube 플레이어(iframe)를 넣습니다.**

**3-2. 탐색 카드 886 × auto** (`padding: 24px 26px 26px`, radius 24px, 플레이어와 같은 솟은 그림자)
- 상단 행(`space-between`, gap 16px):
  - 검색창 **380px**: `padding: 11px 16px`, radius 12px, 함몰
    `inset 4px 4px 8px rgba(142,128,166,0.36), inset -3px -3px 7px rgba(255,255,255,0.85)`.
    17px 돋보기 아이콘 + input(13.5px/500, placeholder "제목, 아티스트, 앨범으로 검색") + 13px X(초기화).
  - **재생** 버튼: pill(`padding: 11px 24px`, radius 99px, 14px/700) + 재생 삼각형.
    활성(카드 선택됨) = 보라 그라디언트 + 솟음 + `cursor: pointer`,
    비활성 = `oklch(0.922 0.013 315)` + 함몰 + `oklch(0.68 0.014 315)` + `cursor: not-allowed`.
- 결과 그리드: `repeat(3, minmax(0,1fr))`, **gap 20px**, 항상 **3개(1줄)**만 표시.
  - 카드: `padding: 10px`, radius 14px. 기본 = 솟음
    `8px 8px 18px rgba(142,128,166,0.45), -6px -6px 14px rgba(255,255,255,0.9)`,
    선택 = 함몰 `inset 5px 5px 11px rgba(150,136,175,0.45), inset -4px -4px 9px rgba(255,255,255,0.9)` +
    배경 `color-mix(in oklab, #b344ff 7%, oklch(0.928 0.013 315))` + 제목 `#6d1a9f`.
  - 썸네일: `aspect-ratio: 16/9`, radius 10px, 대각 줄무늬 + `rgba(179,68,255,0.16)`, 함몰 인셋.
    우하단 재생시간 배지(`rgba(46,34,62,0.72)`, 흰 모노 11px, radius 6px).
  - 하단: 30px 원형 아바타 자리 + 제목(13.5px/600, line-height 18px, **height 36px 고정** = 2줄 클램프) +
    아티스트(12px) + 메타 `{재생 횟수}회 · {앨범}`(11.5px, `oklch(0.55 0.02 315)`).
- 빈 상태: 함몰 박스(`padding: 20px 22px`, radius 12px) + "검색 결과가 없습니다. 다른 제목이나 아티스트로 찾아보세요."

#### 4. 기능 소개 3카드 (886px, `repeat(3, minmax(0,1fr))`, gap 22px)
카드: `padding: 28px`, radius 26px, 솟은 그림자 `14px 14px 30px rgba(142,128,166,0.45), -7px -7px 15px rgba(255,255,255,0.68)`.
52px 아이콘 타일(radius 16px, 솟음, `#6d1a9f` 선 아이콘) + 제목(18px/800) + 본문(13.5px/1.8, `word-break: keep-all`).
1) 손으로 돌리는 디스크 — "CD를 드래그해 구간을 찾습니다. 관성까지 계산해 실제 턴테이블처럼 반응합니다."
2) 제목·아티스트 탐색 — "검색창에 한 번 입력하면 결과가 카드로 나옵니다. 고른 카드가 곧바로 재생됩니다."
3) YouTube 전곡 연결 — "재생은 YouTube에서 그대로 이어집니다. 별도 업로드 없이 검색해서 바로 담으세요."

#### 5. 푸터 (1236px, 상단 `1px solid rgba(255,255,255,0.75)`, `padding: 26px 2px 34px`)
좌: 모노 11px `© 2026 NEUMORPLAYER · POWERED BY YOUTUBE`.
우: `assets/developed-with-youtube.png` 150px 폭, opacity 0.85.

## Interactions & Behavior
- **재생/일시정지**: 디스크 중앙 버튼. `playing`이 true면 1초 간격 타이머로 `t` 증가.
- **디스크 스크럽**: pointerdown 시 현재 재생 상태를 기억하고 일시정지 → pointermove의 각도 변화량을
  누적(`cdAngle`), `transform`만 직접 갱신. 회전 12°당 1초 이동(`cdScrub += Δ/12`, 정수분만 `t`에 반영).
  pointerup에서 원래 재생 상태 복원. 관성: 비드래그 프레임마다
  `cdVel += (target - cdVel) * (playing ? 0.035 : 0.06)`, `target = playing ? 0.28 : 0` (deg/frame).
- **볼륨 노브**: 중심에서 18px 밖에서 시작하면 **각도 모드**(포인터 방향 = 다이얼 각도, ±135° 클램프,
  경계 넘김 방지), 안쪽에서 시작하면 **수직 모드**(위로 끌면 증가, `(prevY - y) * 1.6 * max(0, 1 - r/30)` +
  각도 변화량 합산). 드래그 중에는 setState 없이 `[data-dial]`/`[data-vol-label]`/눈금을 직접 조작하고,
  pointerup에서만 상태 커밋.
- **진행바 시크**: pointerdown에서 일시정지 + 비율 계산 → move로 계속 갱신 → up에서 재생 상태 복원.
- **검색**: 입력값을 `title + " " + artist + " " + album`에 대해 대소문자 무시 부분일치.
  입력이 바뀌면 선택(`pick`)이 해제됩니다. 결과는 상위 3건.
- **카드 선택 → 재생**: 카드 클릭으로 `pick` 지정(함몰 + 액센트 틴트), **재생** 버튼이 활성화되고
  누르면 `index = pick, t = 0, playing = true`로 플레이어가 그 곡으로 교체됩니다. 선택 전에는 버튼 비활성.
- **반복**: 토글. 곡이 끝나면(`t + 1 >= dur`) `t = 0`으로 되돌리고 `playing = repeat`
  (반복이 꺼져 있으면 그 자리에서 정지). **다음 곡으로 넘어가지 않습니다.**
- **호버**: 헤더 링크/버튼은 `#6d1a9f`로, 반복 버튼도 동일. 모든 솟은 버튼은 active에서 함몰로 뒤집힙니다
  (이 반전이 뉴모피즘의 유일한 클릭 피드백이므로 반드시 유지).
- 반응형 없음(고정 1280px 캔버스). 대상 코드베이스에서 유동 폭이 필요하면 886px 컬럼을
  `max-width`로 바꾸고 상단 행만 wrap 처리하는 것을 권합니다.

## State Management
```
index   : number   // 현재 곡의 CATALOG 인덱스 (초기 0)
playing : boolean  // 재생 여부 (초기 true)
t       : number   // 경과 초 (초기 68)
vol     : number   // 0~1 (초기 0.72)
query   : string   // 검색어 (초기 "")
pick    : number | null // 선택된 결과의 CATALOG 인덱스 (초기 null)
repeat  : boolean  // 반복 (초기 false)
```
비상태(ref) 값: `cdAngle`, `cdVel`, `cdDragFrom`, `cdScrub`, `knobA`, `knobDragging`, `seekRect`.
**이 값들은 프레임마다 바뀌므로 절대 상태로 만들지 마세요.** DOM을 직접 만지고, 드래그가 끝날 때만 커밋합니다.
타이머/rAF는 마운트 시 1개씩만 유지하고 언마운트에서 정리합니다.

데이터: `CATALOG` 10곡(제목/아티스트/앨범/재생시간/재생 횟수). 실제 구현에서는 YouTube Data API
검색 결과로 대체하고, 재생은 YouTube IFrame Player API에 위임하세요(현재 진행바·타이머는 목입니다).

## Design Tokens
**색**
- 페이지 배경 `oklch(0.925 0.014 315)`
- 카드 표면 `oklch(0.935 0.013 315)` / 함몰 표면 `oklch(0.915 0.014 315)`, `oklch(0.908 0.014 315)`
- 디스크 바탕 `oklch(0.905 0.014 315)`
- 잉크 `oklch(0.3 0.025 315)` / 보조 `oklch(0.47 0.025 315)` / 약함 `oklch(0.55 0.02 315)`
- 액센트(하이라이트) `#6d1a9f` / 액센트 원색 `#b344ff` / 틴트 `rgba(179,68,255,0.16)`
- 액센트 버튼 그라디언트 `linear-gradient(155deg, oklch(0.94 0.038 312), oklch(0.885 0.055 312))`
- 비활성 텍스트 `oklch(0.68~0.72 0.014 315)`

**그림자 (뉴모피즘 핵심)**
- 솟음 L `15px 15px 30px rgba(142,128,166,0.5), -7px -7px 15px rgba(255,255,255,0.65)`
- 솟음 M `8px 8px 18px rgba(142,128,166,0.45), -6px -6px 14px rgba(255,255,255,0.9)`
- 솟음 S(버튼) `4px 4px 10px rgba(146,132,170,0.5), -3px -3px 8px rgba(255,255,255,0.95)`
- 함몰 L `inset 5px 5px 12px rgba(150,136,175,0.42), inset -4px -4px 9px rgba(255,255,255,0.9)`
- 함몰 M(입력) `inset 4px 4px 8px rgba(142,128,166,0.36), inset -3px -3px 7px rgba(255,255,255,0.85)`
- 함몰 S(버튼 active) `inset 4px 4px 9px rgba(146,132,170,0.6), inset -3px -3px 7px rgba(255,255,255,0.9)`
- 테두리 하이라이트 `1px solid rgba(255,255,255,0.7~0.85)`

**타이포**
- 디스플레이: Space Grotesk 700 — 92px/0.96(히어로), 16px(워드마크)
- 본문: Manrope + Noto Sans KR — 800 (26/22/20/18/16px 제목), 600/500 (13.5/13/12.5/12px 본문)
- 모노: IBM Plex Mono 400/500 — 10~12px, letter-spacing 0.1~0.18em (라벨·시간·수치)
- 한국어 본문에는 `word-break: keep-all` + `text-wrap: pretty` 필수

**간격 / 반경**
- 섹션 간 78px, 블록 간 18~22px, 카드 내부 10~28px
- radius: 페이지 카드 24~26px, 헤더 22px, 동영상 20px, 결과 카드 14px, 입력 12px, 버튼 13~16px, pill 99px
- 폭: 캔버스 1280(패딩 22) / 콘텐츠 컬럼 886 / 플레이어 340 / 동영상 528 / 검색창 380

## Assets
- `assets/developed-with-youtube.png` — 푸터의 YouTube 개발자 배지. 원본 그대로 복사했습니다.
- 앨범 아트·아바타·동영상 썸네일은 모두 CSS 줄무늬 플레이스홀더입니다. 실제 구현에서는
  YouTube 썸네일 URL로 대체하세요.
- 아이콘은 모두 인라인 SVG(재생·일시정지·반복·검색·닫기·디스크·목록·모니터)입니다.
  대상 코드베이스에 아이콘 세트가 있으면 같은 무게(stroke 1.7~2px)로 교체하세요.

## Screenshots
- `screenshots/01-landing-full.png` — 랜딩 페이지 전체(1280px 캔버스, 2x).
- `screenshots/02-player-video.png` — 제품 영역: 플레이어 340×297 + 동영상 528×297 + 탐색 카드 886px (2x).

## Files
- `Neumorphism Landing.dc.html` — 랜딩 페이지 전체(마크업 + 로직). 이 파일이 기준입니다.
- `support.js` — Design Component 런타임(프리뷰용). **이식 대상이 아닙니다.**
- `assets/developed-with-youtube.png` — 푸터 배지 이미지.
- 참고: `Music Player Dashboard.dc.html`(이 번들에는 없음) — 랜딩의 플레이어·탐색 UI가 유래한 대시보드 원본.
