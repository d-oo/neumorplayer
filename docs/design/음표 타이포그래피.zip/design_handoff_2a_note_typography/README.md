# 2a · 음표 타이포그래피 — 핸드오프

`index.html`을 브라우저에서 열면 그대로 렌더됩니다. 원본: `Neumorphism Landing.dc.html`의 2a 섹션.

## 구성
- 두 줄 타이틀 "Neumorphism / Music Player". 일부 글자를 인라인 SVG 음표로 치환.
  - N, M(대문자) → 8분음표 2개 / 3개 빔 연결 (높이 0.7em = 캡하이트)
  - m(소문자) → 8분음표 3개 빔 연결 (높이 0.5em = x-하이트)
  - p, P → 2분음표 180° 회전 (소문자 p: 0.73em, vertical-align -0.22em로 디센더 / 대문자 P: 0.7em)
- SVG는 `fill="currentColor"` → 부모 텍스트 색을 따름. 높이가 em 단위라 font-size만 바꾸면 비율 유지.
- 1 viewBox 단위 ≈ 0.00972em. 음표 기둥 폭 8.5, 머리 타원 rx 10 / ry 8, -25° 회전. 빔 두께 13, 오른쪽이 살짝 올라감.
- 2분음표 구멍은 SVG `<mask>` (id `hp1`, `hp2` — 여러 개 렌더 시 id 중복 주의). 기둥 끝 둥글게 (rx 4.75).

## 토큰
- 폰트: Fredoka 500, 92px, line-height 0.96, letter-spacing -0.015em
- 배경: oklch(0.925 0.014 315)
- 1줄 색: oklch(0.34 0.03 315) / 2줄 색: #6d1a9f
- 텍스트 그림자(뉴모피즘): `2px 2px 3px rgba(255,255,255,0.95), -2px -2px 4px rgba(128,108,158,0.45)` (2줄은 알파 0.5)
- SVG는 text-shadow가 안 먹으므로 동일한 값을 `filter: drop-shadow(...)` 두 겹으로 적용

## 구현 팁
- 각 음표 SVG를 `<NoteGlyph type="n|m|p" case="upper|lower" />` 같은 컴포넌트로 분리 권장.
- 스크린리더용으로 각 SVG에 aria-label(원래 글자)이 있음. 컨테이너에 `aria-label="Neumorphism Music Player"`를 주고 내부는 aria-hidden 처리해도 됨.
