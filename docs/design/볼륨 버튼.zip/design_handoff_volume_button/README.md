# 코드 이관용 — 1a 볼륨 버튼 (클릭 토글)

## 파일
- `Volume Button.dc.html` — 1a 볼륨 버튼 (출처: `Volume & Search.dc.html` 1a). 로직은 이 버튼에 필요한 것만 남김.
- `support.js` — 런타임. 같은 폴더에 있어야 브라우저에서 바로 열립니다.

## 동작
- 볼륨 50% 고정. 눈금·드래그 회전 없음. 다이얼은 회전 0°(표시선 12시 방향).
- 클릭하면 눌림(비활성) 상태, 다시 클릭하면 원래 상태. 상태 키: `muted` (boolean). `aria-pressed`에 반영.
- 전환: 모든 속성 0.22s. 크기는 `cubic-bezier(0.3, 0.7, 0.4, 1)`.

## 구조 (92×92 히트 영역)
```
knob (92×92, cursor:pointer)
└─ cap wrapper (100%, transform: scale)
   ├─ base  60×60 원  — 돌출/함몰 그림자
   └─ dial  50×50 원  — conic-gradient 금속 질감
      └─ pointer 3×10, top 5px
label "50%" (IBM Plex Mono 12px, margin-top -10px)
```

## 상태별 값
| 요소 | 기본 | 눌림 |
|---|---|---|
| wrapper transform | `scale(1)` | `scale(0.94)` |
| base 배경 | `oklch(0.935 0.013 315)` | `oklch(0.922 0.012 315)` |
| base 그림자 | `6px 6px 14px rgba(146,132,170,0.55), -5px -5px 12px rgba(255,255,255,0.95)` | `inset 5px 5px 11px rgba(146,132,170,0.5), inset -4px -4px 9px rgba(255,255,255,0.9)` |
| dial 그림자 | `inset 2px 2px 5px rgba(146,132,170,0.35), inset -2px -2px 5px rgba(255,255,255,0.9)` | `inset 1px 1px 3px rgba(146,132,170,0.25), inset -1px -1px 3px rgba(255,255,255,0.6)` |
| dial opacity | 1 | 0.55 |
| pointer | `#6d1a9f` | `oklch(0.72 0.015 315)` |
| label | `oklch(0.38 0.025 315)` | `oklch(0.64 0.015 315)` |

그림자 전환이 자연스럽도록 base 그림자는 inset 2개 + outset 2개를 항상 같은 개수로 유지하고, 쓰지 않는 쪽은 0으로 둡니다.

dial의 conic-gradient:
```
conic-gradient(from 210deg, oklch(0.93 0.012 315), oklch(0.98 0.006 315) 9%, oklch(0.87 0.016 315) 23%, oklch(0.96 0.008 315) 37%, oklch(0.875 0.016 315) 51%, oklch(0.97 0.007 315) 65%, oklch(0.87 0.016 315) 79%, oklch(0.95 0.009 315) 91%, oklch(0.93 0.012 315))
```
