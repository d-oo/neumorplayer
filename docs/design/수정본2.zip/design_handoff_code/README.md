# 코드 이관용 화면 묶음 (1b-A / 1b-B / 3a / 3b)

## 파일
- `Playlist Panels.dc.html` — **1b-A 재생목록 정보**, **1b-B 트랙 상세 정보** (출처: `Music Player Dashboard.dc.html`)
- `Auth Screens.dc.html` — **3a 로그인**, **3b 회원가입** (출처: `Music Player Dashboard.dc.html` — 최신본)
- `support.js` — 두 파일이 로드하는 런타임. 같은 폴더에 있어야 브라우저에서 바로 열립니다.

각 파일은 원본의 `<helmet>`(폰트/키프레임/리셋)과 로직 클래스를 그대로 유지하고, 해당 섹션만 남긴 사본입니다. 다른 섹션에서만 쓰이는 로직 키가 일부 남아 있을 수 있습니다(동작에는 영향 없음).

## 화면별 구현 메모
### 1b-A 재생목록 정보 (폭 844px)
- 커버 플레이스홀더 248×139 + 제목/곡수·길이
- 버튼 행: 재생(액센트 그라디언트) · 셔플 · 구분선 · 수정 · 삭제 — 모두 44px 원형, 호버 시 툴팁이 **위로** 표시
- 트랙 테이블 열: `# / 제목 / 태그 / 재생 횟수 / 시간` (grid `34px minmax(0,1fr) 170px 92px 62px`)

### 1b-B 트랙 상세 정보 (844×729 고정)
- 헤더는 트랙 제목·아티스트만 (버튼 없음)
- 버튼 행: 재생 · 재생목록에 추가 · 수정 · 삭제 — 44px 원형, 툴팁 위쪽
- `재생목록에 추가`는 모달을 열고, 추가 후 액센트 색 안내 문구를 노출

### 3a 로그인 / 3b 회원가입 (1200×824 캔버스, 카드 뉴모피즘)
- 입력 필드: height 48px, radius 13px, inset 그림자(함몰)
- 기본 버튼: height 50px, radius 14px, 보라 텍스트 `#6d1a9f` + 돌출 그림자 → active 시 함몰
- 3a는 로그인 상태 유지 / 비밀번호 찾기 / 소셜 로그인 / 하단 가입 링크 포함
- 3b는 약관 동의 체크와 하단 로그인 링크 포함

## 공통 토큰
```
--ink  oklch(0.3 0.025 315)     본문
--mut  oklch(0.47 0.025 315)    보조 텍스트
--hi   #6d1a9f                  보라 액센트(텍스트/링크)
--acc-base #b344ff              액센트 원색 (acc / acc-soft / acc-dim 파생)
surface      oklch(0.935 0.013 315)
inset field  oklch(0.908 0.014 315)
radius       카드 24px · 필드 13px · 버튼 14px · 알약 99px
type         Manrope + Noto Sans KR / 라벨·수치 IBM Plex Mono / 워드마크 Space Grotesk
```
돌출: `box-shadow: 7px 7px 16px rgba(150,136,175,0.45), -5px -5px 12px rgba(255,255,255,0.95)`
함몰: `box-shadow: inset 5px 5px 11px rgba(150,136,175,0.5), inset -4px -4px 9px rgba(255,255,255,0.95)`
